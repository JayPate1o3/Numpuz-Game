# 'BOA' Example
  The program is "lexically" correct
  and should not generate any error #
main& {
	data {
	}
	code {
		print&('Hello world!');
	}
}
